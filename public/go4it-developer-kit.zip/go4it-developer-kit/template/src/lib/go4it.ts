// GO4IT template version — used by upgradeTemplateInfra to apply only newer patches.
// Bump this when the template gains new infrastructure features.
export const GO4IT_TEMPLATE_VERSION = 2;
