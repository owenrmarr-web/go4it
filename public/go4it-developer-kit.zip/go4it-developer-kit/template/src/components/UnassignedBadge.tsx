export default function UnassignedBadge() {
  return (
    <span className="bg-elevated text-fg-dim text-xs font-medium rounded-full px-2.5 py-0.5">
      Not on plan
    </span>
  );
}
